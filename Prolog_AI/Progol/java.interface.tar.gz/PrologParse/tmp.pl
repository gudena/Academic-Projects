a :- [a,b].
a:- (a,b).

